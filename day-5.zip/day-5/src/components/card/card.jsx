import React from "react";
import { request } from "../../config/request";
import { Form } from "../form/form";

export const Card = (del) => {
  const [state, setState] = React.useState([]);

  React.useEffect(() => {
    request.get("/posts").then((res) => {
      setState(res.data);
    });
  }, []);

  return (
    <>
      <div>
        <Form />
        {state.map((item) => (
          <div key={item.id}>
            <li>{item.title}</li>
            <button onClick={del} type="submit" key={item.id}>
              Delete
            </button>
          </div>
        ))}
      </div>
    </>
  );
};
